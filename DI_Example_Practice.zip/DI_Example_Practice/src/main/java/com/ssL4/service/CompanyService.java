package com.ssL4.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssL4.model.Account;
import com.ssL4.model.Address;
import com.ssL4.model.Company;

@Service
public class CompanyService {
    @Autowired
    private Company company;

    public Company setCompanyDetailsAndDisplay() {
        company= new Company("Example Company", "Owner", new Address("name", "pincode"), new Account("HolderName", "Account"));
        return company;
    }
}