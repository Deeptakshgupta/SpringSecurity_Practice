package com.ssL4.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Component
public class Company {

	public Company(String name, String ownerName, Address address, Account account) {
		super();
		this.name = name;
		this.ownerName = ownerName;
		this.address = address;
		this.account = account;
	}
	  public Company() {
	        // Default constructor
	    }

	private String name;
	private String ownerName;

	@Autowired
	private Address address;

	@Autowired
	private Account account;
}
