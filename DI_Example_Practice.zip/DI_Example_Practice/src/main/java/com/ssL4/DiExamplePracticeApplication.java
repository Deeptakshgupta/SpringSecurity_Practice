package com.ssL4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiExamplePracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiExamplePracticeApplication.class, args);
	}

}
